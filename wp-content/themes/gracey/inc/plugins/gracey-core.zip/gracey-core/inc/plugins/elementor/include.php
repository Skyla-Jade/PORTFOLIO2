<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once GRACEY_CORE_PLUGINS_PATH . '/elementor/helper.php';
	include_once GRACEY_CORE_PLUGINS_PATH . '/elementor/class-graceycore-elementor-section-handler.php';
}
