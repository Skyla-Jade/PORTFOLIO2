<?php

include_once GRACEY_CORE_INC_PATH . '/left-fixed-area/helper.php';