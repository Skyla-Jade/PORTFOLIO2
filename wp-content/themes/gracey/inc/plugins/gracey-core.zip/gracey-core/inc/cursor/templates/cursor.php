<div id="qodef-theme-cursor">
	<svg x="0px" y="0px" width="44px" height="44px" viewBox="0 0 44 44">
		<g class="qodef-cursor-square">
			<path d="M21.997 63.07l-40.941-40.94 40.941-40.942L62.938 22.13z"></path>
		</g>
		<g class="qodef-cursor-cross">
			<path d="M22.3 44.2h-.6V26.1c0-2-1.6-3.6-3.6-3.6H0v-.6h18.1c2 0 3.6-1.6 3.6-3.6V.2h.6v18.1c0 2 1.6 3.6 3.6 3.6H44v.6H25.9c-2 0-3.6 1.6-3.6 3.6v18.1z"></path>
		</g>
	</svg>
</div>