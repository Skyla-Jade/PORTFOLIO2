<?php

include_once GRACEY_CORE_INC_PATH . '/icons/ionicons/class-graceycore-ionicons-pack.php';
