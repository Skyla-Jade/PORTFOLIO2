<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php echo do_shortcode( '[woocommerce_order_tracking]' ); // XSS OK ?>
</div>
