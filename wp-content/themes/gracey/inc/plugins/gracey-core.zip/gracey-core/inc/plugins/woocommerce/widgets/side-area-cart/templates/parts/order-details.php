<div class="qodef-m-order-details">
	<h6 class="qodef-m-order-label"><?php esc_html_e( 'Total:', 'gracey-core' ); ?></h6>
	<div class="qodef-m-order-amount"><?php wc_cart_totals_subtotal_html(); ?></div>
</div>
