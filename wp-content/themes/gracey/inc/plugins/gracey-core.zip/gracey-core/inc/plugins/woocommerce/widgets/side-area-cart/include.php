<?php

include_once GRACEY_CORE_PLUGINS_PATH . '/woocommerce/widgets/side-area-cart/class-graceycore-woocommerce-side-area-cart-widget.php';
