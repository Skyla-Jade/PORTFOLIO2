<?php

include_once GRACEY_CORE_INC_PATH . '/icons/kiko/class-graceycore-kiko-icons-pack.php';