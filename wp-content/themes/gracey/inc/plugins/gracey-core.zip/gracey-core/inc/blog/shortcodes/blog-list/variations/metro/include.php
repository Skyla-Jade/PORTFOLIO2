<?php

include_once GRACEY_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/metro/metro.php';
