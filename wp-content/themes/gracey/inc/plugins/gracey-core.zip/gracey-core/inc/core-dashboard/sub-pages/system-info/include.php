<?php

include_once GRACEY_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-graceycore-dashboard-system-info-page.php';
