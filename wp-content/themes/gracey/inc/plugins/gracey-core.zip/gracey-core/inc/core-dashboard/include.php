<?php

include_once GRACEY_CORE_INC_PATH . '/core-dashboard/class-graceycore-dashboard.php';
