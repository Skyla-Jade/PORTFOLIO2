<div class="qodef-m-order-details">
	<span class="qodef-m-order-label"><?php esc_html_e( 'Total:', 'gracey-core' ); ?></span>
	<div class="qodef-m-order-amount"><?php wc_cart_totals_subtotal_html(); ?></div>
</div>
