<?php

include_once GRACEY_CORE_INC_PATH . '/icons/elegant-icons/class-graceycore-elegant-icons-pack.php';
