<?php

include_once GRACEY_CORE_INC_PATH . '/icons/simple-line-icons/class-graceycore-simple-line-icons-pack.php';
