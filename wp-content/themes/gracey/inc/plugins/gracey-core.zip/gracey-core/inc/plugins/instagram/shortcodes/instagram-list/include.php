<?php

include_once GRACEY_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-graceycore-instagram-list-shortcode.php';
