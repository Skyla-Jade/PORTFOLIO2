<?php

include_once GRACEY_CORE_INC_PATH . '/icons/font-awesome/class-graceycore-font-awesome-pack.php';
